# Indonesia ERP Software Market — Structured Dataset

This repository contains a structured dataset based on publicly available information from the **Indonesia ERP Software Market** report by NextMSC.

## 📁 Dataset Contents
- `market_overview.csv`
- `segmentation.csv`
- `metadata.json`
- `README.md`

## 📊 Data Description

### 1. Market Overview
Includes:
- Market Size (2024, 2025, 2030)
- CAGR (2025–2030)

### 2. Market Segmentation
Segments include:
- Component (Software, Services)
- Deployment Mode (On-Premise, Cloud, Hybrid)
- Enterprise Size (SMEs, Large Enterprises)
- Industry Verticals (Manufacturing, BFSI, Healthcare, Retail & Distribution, Government, IT & Telecom, Construction, Others)

## 📚 Source
https://www.nextmsc.com/report/indonesia-erp-software-market-ic3612

## ⚠️ Disclaimer
This dataset is structured manually for research and educational use only.
